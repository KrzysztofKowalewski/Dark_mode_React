import React, { Component } from "react";

class Jakiestresci extends Component{
    
    trybnocny(){
        const zmiana = document.body
        zmiana.classList.toggle("dark-mode")
    }
    
    render(){
        
        
        return(
            <div>
                <h1>Jakis naglowek</h1>
                <h4>Jakas tam tresc</h4>
                <button onClick={this.trybnocny}>Tryb nocny</button>
            </div>
        )
        
        
    }
}

export default Jakiestresci