import './App.css';
import './components/Jakiestresci'
import Jakiestresci from './components/Jakiestresci';

function App() {
  return (
    <div >
      <Jakiestresci/>
    </div>
  );
}

export default App;
